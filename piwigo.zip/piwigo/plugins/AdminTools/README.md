# Piwigo AdminTools

* Internal name: `AdminTools` (directory name in `plugins/`)
* Plugin page: http://piwigo.org/ext/extension_view.php?eid=720
* Translation: http://piwigo.org/translate/project.php?project=admin_tools
